export { default as baseSizes } from './base.json';
export { default as fontSizes } from './font.json';
