export { default as baseColors } from './base.json';
export { default as gradientColors } from './gradient.json';
