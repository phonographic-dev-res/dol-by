export { ReactComponent as DolbyIoLogo } from './svg/dolby-io-logo.svg';
