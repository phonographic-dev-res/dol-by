export enum GradientTypes {
  BlueToLightBlue = 'blueToLightBlue',
  BlueToPurple = 'blueToPurple',
  PurpleToLightPink = 'purpleToLightPink',
  PurpleToPink = 'purpleToPink',
  BlueToGreen = 'blueToGreen',
  LightBlueToGreen = 'lightBlueToGreen',
}
