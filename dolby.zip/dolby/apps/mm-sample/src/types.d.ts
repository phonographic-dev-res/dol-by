/// <reference types="@emotion/react/types/css-prop" />

export {};
declare global {
  interface Window {
    webkitAudioContext: typeof AudioContext
  }
}