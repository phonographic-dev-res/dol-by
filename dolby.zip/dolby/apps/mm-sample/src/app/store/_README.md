### Store

Application state management (Redux).

## Persist store data to local store

In order to persist store data across app loads, use the query parameter `persist-data` and set it to `true`.
