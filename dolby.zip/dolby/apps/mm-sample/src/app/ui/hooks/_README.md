## Functional Component Hooks

Hooks defined in this directory must only be used in React Functional components. See https://reactjs.org/docs/hooks-rules.html for more info.
