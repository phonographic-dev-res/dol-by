### UI

Views (React functional components) and business logic (React hooks).
