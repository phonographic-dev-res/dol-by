### Utils

Generally these utilities will be written in plain Typescript. Files here should not have FE framework/library specific dependencies.
